// Import packagge
var mongodb = require('mongodb');
var ObjectID = mongodb.ObjectID;
var crypto = require('crypto');
var express = require('express');
var bodyParser = require('body-parser');
const { request } = require('http');

//PASSWORD UTILS
//CREATE FUNCTION TO RANDOM SALT
/*var genRandomString = function(length){
   return crypto.randomBytes(Math.ceil(length/2))
      .toString('hex')
      .slice(0,length);
}

var sha512 = function(password, salt){
   var hash = crypto.createHmac('sha512',salt);
   hash.update(password);
   var value = hash.digest('hex');
   return {
      salt:salt,
      passwordHash:value
   };
}

function saltHashPassword(userPassword){
   var salt = genRandomString(16);
   var passwordData = sha512(userPassword,salt);
   return passwordData;
}

function checkHashPassword(userPassword,salt){
   var passwordData = sha512(userPassword,salt);
   return passwordData;
} */

//Create Express Service
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

//Create MongoDB Client
var MongoClient = mongodb.MongoClient;

//Connection URL
var url = 'mongodb://localhost:27017' // 27017 is default port
//var url = 'mongodb+srv://user:asdf@cluster0.9pj7n.mongodb.net/test?retryWrites=true&w=majority'

MongoClient.connect(url, {useNewUrlParser: true},function(err,client) {
   if(err)
      console.log('Unable to connect to the mongoDB server.Error',err);
   else
   {
      //Register
      app.post('/register',(request,response) =>{

         var post_data = request.body;
         //var plain_password = post_data.password;
         //var hash_data = saltHashPassword(plain_password);

         //var password = hash_data.passwordHash;
         //var salt = hash_data.salt;

         var password = post_data.password;
         var phone_number = post_data.phone_number;
         var name = post_data.name;
         var email = post_data.email;

         var insertJson = {
            'email': email,
            'password': password,
            'name': name,
            'phone_number' : phone_number,
            'profile' : ""
         };
         var db = client.db('madcamp') //db 이름

         //check exists email
         db.collection("user")  // collection 이름
            .find({'email':email}).count(function(err,number){
               if(number!=0)
               {
                  response.json("Email already exists");
                  console.log("Email already exists");
               }
               else
               {
                  db.collection("user")
                     .insertOne(insertJson,function(error,res){
                        response.json("Registration succeed");
                        console.log("Registration succeed");
                     })
                  db.createCollection(email);
                  db.createCollection(email+"_msg");
                  db.createCollection(email+"_profile");
                  db.collection(email+"_profile").insertOne({'number': "1", 'bitmap':""});
                  db.collection(email+"_profile").insertOne({'number': "2", 'bitmap':""});
                  db.collection(email+"_profile").insertOne({'number': "3", 'bitmap':""});
               }
         })
      });

      //LOGIN
      app.post('/login',(request,response) =>{

         var post_data = request.body;

         var password = post_data.password;
         var email = post_data.email;

         var db = client.db('madcamp')

         db.collection("user")
            .find({'email':email}).count(function(err,number){
               if(number==0)
               {
                  response.json("Email does not exists");
                  console.log("Email does not exists");
               }
               else
               {
                  //
                  db.collection("user")
                     .findOne({'email':email},function(err,user){

                        //var salt = user.salt;
                        //var hashed_password = checkHashPassword(password,salt).passwordHash;
                        //var encrypted_password = user.password;
                        var name = user.name;

                        if(password == user.password)
                        {
                           response.json('Login success/' +name);
                           console.log('Login success / '+name);
                        }
                        else
                        {
                           response.json('Wrong password');
                           console.log('Wrong password');   
                        }

                     })
               }

            })
      })

      // facebook 로그인 시에 phone_number check
      app.post('/facebook_login_check', (request, response) =>{
         var post_data = request.body;

         var email = post_data.email;
         var name = post_data.name;

         var db = client.db('madcamp')

         db.collection("user")
            .find({'email':email}).count(function(err,number){
               if(number==0)
               {
                  var insertJson = {
                     'email': email,
                     'password': "",
                     'name': name,
                     'phone_number' : null,
                     'profile' : ""
                  };
                  db.collection("user").insertOne(insertJson);
                  db.createCollection(email);
                  db.createCollection(email+"_msg");
                  db.createCollection(email+"_profile");
                  db.collection(email+"_profile").insertOne({'number': "1", 'bitmap':""});
                  db.collection(email+"_profile").insertOne({'number': "2", 'bitmap':""});
                  db.collection(email+"_profile").insertOne({'number': "3", 'bitmap':""});

                  response.json("Push");
                  console.log("Push");
               }
               else{
                  response.json("Ok/"+name);
                  console.log("Ok/"+name);
               }
            })
      })

      // password와 phone number를 받아서 update
      app.post('/facebook_login_number_push', (request, response) =>{
         var post_data = request.body;

         var email = post_data.email;
         var phone_number = post_data.phone_number;
         var password = post_data.password;

         var db = client.db('madcamp')

         db.collection("user")
            .update({'email':email}, { $set : {'phone_number': phone_number, 'password': password}}, function(err, res){
               response.json("facebook phone number register");
               console.log("facebook phone number register");
            });
      })
      
      //모든 유저 정보 넘김
      app.get('/print_all',(request,response) =>{

         var db = client.db('madcamp');
         db.collection("user").find().toArray(function(err, us){
            response.json(us);
            //console.log(us);
         })
      })

      //자신이 추가한 연락처 정보
      app.post('/getContact', (request, response) =>{
         console.log("tab1 view start!!");
         var email = request.body.email;
         var db = client.db('madcamp');
         db.collection(email).find().toArray(function(err, us){
            response.json(us);
            console.log(us);
         })
      })

      app.post('/AddContact', (request, response) =>{
         var post_data = request.body;

         var user_email = post_data.user_email;
         var name = post_data.name;
         var email = post_data.email;
         var phone_number = post_data.phone_number;
         var profile = "";
         var db = client.db('madcamp')

         db.collection('user').find({'email':email}).count(function(err, count) {
            if (count == 0) {
               var insertJson = {
                  'name': name,
                  'email': email,
                  'phone_number' : phone_number,
                  'profile' : profile
               };
      
               var db = client.db('madcamp')
      
               //check exists email
               db.collection(user_email).find({'email':email}).count(function(err,count){
                     if(count!=0)
                     {
                        response.json("Email already exists");
                        console.log("Email already exists");
                     }
                     else
                     {
                        db.collection(user_email)
                           .insertOne(insertJson,function(error,res){
                              response.json("Local Registration succeed");
                              console.log("Local Registration succeed");
                           });
                        
                     }
               })
            }
            else {
               db = client.db('madcamp');
               console.log("here");
               db.collection('user').findOne({'email':email}, function(err, user) {
                  profile = user.profile;
                  var insertJson = {
                     'name': name,
                     'email': email,
                     'phone_number' : phone_number,
                     'profile' : profile
                  };
         
                  var db = client.db('madcamp')
         
                  //check exists email
                  db.collection(user_email).find({'email':email}).count(function(err,count){
                        if(count!=0)
                        {
                           response.json("Email already exists");
                           console.log("Email already exists");
                        }
                        else
                        {
                           db.collection(user_email).insertOne(insertJson,function(error,res){
                                 response.json("Local Registration succeed");
                                 console.log("Local Registration succeed");
                              });
                           
                        }
                  })
               })
            }
         })
      })

      app.post('/DeleteContact', (request, response) =>{
         var post_data = request.body;

         var user_email = post_data.user_email;
         var email = post_data.email;

         var db = client.db('madcamp');
         
         db.collection(user_email).remove({'email':email}, function(err, res){
            response.json("remove contact success");
            console.log("remove contact success");
         })
      })

      //tab2 => change my profile
      app.post('/Change_profile', (request, response) =>{
         var post_data = request.body

         var email = post_data.email;
         var number = post_data.number;
         var bitmap = post_data.bitmap;
         console.log(email);
         console.log("number is "+number);
         var db = client.db('madcamp');
         db.collection(email+"_profile").update({'number':number}, { $set : {'bitmap' : bitmap}}, function(err, res){
            if (number == '1'){
               db.collection('user').update({'email':email}, { $set : {'profile' : bitmap}});
            }
            response.json("profile changed");
            console.log("profile changed");
         })
      })

      //tab2 => get my profile
      app.post('/Get_profile', (request, response) =>{
         console.log("get profile start");
         var post_data = request.body;

         var email = post_data.email;

         var db = client.db('madcamp');
         db.collection(email).find().toArray(function(err, us){
            response.json(us);
            //console.log(us);
         })
      })
      
      //user click 시에 메세지를 보낼 수 있는지 없는지
      app.post('/SendOrNot', (request, response) =>{
         var post_data = request.body;

         var email = post_data.email;
         var user_email = post_data.user_email;

         db = client.db('madcamp');
         console.log(email+" / "+user_email);
         db.collection('user').find({'email':email}).count(function(err,number){
            if (number == 0){
               response.json("CANNOT");
               console.log("CANNOT");
            }
            else{
               response.json("CAN");
               console.log("CAN");
            }
         })
      })

      //tab2 => 모든 프로필 사진 뿌리기
      app.get('/Get_All_profile', (request, response) =>{
         console.log("Get_All_profile start!")
         db = client.db('madcamp')
         db.collection('user').find({}, {_id:0, email:0, password:0, name:0, phone_number:0, profile:1}).toArray(function(err, user){
            response.json(user);
            console.log(user);
         })
      })

      // Send Message
      app.post('/SendMsg', (request, response) =>{
         var post_data = request.body
         
         var email = post_data.email;
         var user_name = post_data.user_name;
         var user_email = post_data.user_email;
         var msg = post_data.msg;
         var visible = "0";

         db = client.db('madcamp');

         db.collection(user_email+"_msg").find({'email':email}).count(function(err, count){
            if (count !=0 ){
               visible = "1"
               console.log("wow!!!! comma~~~~");
               db.collection(user_email+"_msg").update({'email':email}, {$set : {'visible' : 1}}, function(err, res){
                  console.log("change visible");
                  var insertJson = {
                     'email': user_email,
                     'name' : user_name,
                     'msg' : msg,
                     'visible' : visible
                  };
                  db=client.db('madcamp');
                  db.collection(email+"_msg").insertOne(insertJson, function(err, res){
                     response.json("1");
                     console.log("visible msg");
                  });
               } );
            }
            else{
               var insertJson = {
                  'email': user_email,
                  'name' : user_name,
                  'msg' : msg,
                  'visible' : visible
               };
      
               db.collection(email+"_msg").insertOne(insertJson, function(err, res){
                  response.json("0");
                  console.log("not visible msg");
               });
            }
         })
      })

      // Get Message
      app.post('/Get_Message', (request, response) =>{
         console.log("Get Message start!!!");
         var post_data = request.body

         var email = post_data.email;

         var db = client.db('madcamp');
         db.collection(email+"_msg").find().toArray(function(err, user) {
            response.json(user);
            console.log(user);
         })
      })
      //Start Web Server
      app.listen(80,()=>{
         console.log('Connected to MongoDB Server, Webservice running on port 80')
      })
   }

})
